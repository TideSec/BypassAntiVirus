/*
 * definitions for auxiliary functions
 */
DWORD findPidByName(wchar_t * pname);
VOID displayHelp();
DWORD getThreadID(DWORD pid);
BOOL SetSePrivilege();
