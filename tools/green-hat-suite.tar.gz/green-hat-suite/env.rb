#!/usr/bin/env ruby
# -*- coding: binary -*-
# Code by Green-m
# Test  on ruby 2.3.3
$LOAD_PATH.unshift(File.dirname(__FILE__))

require 'lib/output'
require 'lib/utils'
require 'lib/console'
require 'lib/skeleton'
require 'lib/exemaker'
require 'lib/payloadmaker'