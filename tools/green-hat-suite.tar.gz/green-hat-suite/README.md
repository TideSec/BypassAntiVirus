# Green-hat-suite
-------------------------------------------
```
  ____                       _           _               _ _       
 / ___|_ __ ___  ___ _ __   | |__   __ _| |_   ___ _   _(_) |_ ___ 
| |  _| '__/ _ \/ _ \ '_ \  | '_ \ / _` | __| / __| | | | | __/ _ \
| |_| | | |  __/  __/ | | | | | | | (_| | |_  \__ \ |_| | | ||  __/
 \____|_|  \___|\___|_| |_| |_| |_|\__,_|\__| |___/\__,_|_|\__\___|
                                                                   
```

Green-hat-suite is a tool to make meterpreter evade antivirus.  

Put this green hat on others head. 

## To do 
- [x] Add windows meterpreter service. 
- [x] Add installation automatically script on windows. 
- [ ] Add more document.


## Install on Kali/ubuntu/debian
```
# msf installed default on kali
apt-get install metasploit-framework 
gem install os   
apt-get install mingw-w64
apt-get install wine

# install tdm-gcc from sourceforge
TMP=`mktemp /tmp/XXXXXXXXX.exe` && wget https://sourceforge.net/projects/tdm-gcc/files/latest/download -O $TMP && wine $TMP && rm $TMP
```

## Install on windows (Recommanded)   

Now we have a automatically installation script on windows. 

Download it and run `install.ps1` with administartor rights.

The installation will last several hours, be patient. 

## Start green-hat-suite  

see https://github.com/Green-m/green-hat-suite/wiki/Use-green-hat-suite 

Contact to me If you have any question.  

Do not do evil.
