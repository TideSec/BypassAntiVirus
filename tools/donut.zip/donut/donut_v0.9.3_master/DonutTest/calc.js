
var sh  
sh = new ActiveXObject("Wscript.Shell")  
sh.Run("calc.exe")  
WScript.Quit()