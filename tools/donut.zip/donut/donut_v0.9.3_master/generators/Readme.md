# Generators

This folder contains Donut generators written in other languages than C. They are all developed by third-parties and are maintained separately, but are linked here as submodules. To clone Donut along with the submodules, run:

```
git clone https://github.com/TheWover/donut.git --recursive
```