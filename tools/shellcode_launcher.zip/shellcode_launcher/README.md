shellcode_launcher
==================

Shellcode launcher utility written to support the labs for the incredibly awesome book Practical Malware Analysis (http://practicalmalwareanalysis.com/)


