#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "498e6ee058"     # abbreviated commit hash
commit = "498e6ee058915e5eb5f170f7a17f918c1f4d4cce"  # commit hash
date = "2019-07-09 21:12:15 +0200"   # commit date
author = "Hartmut Goebel <h.goebel@crazy-compilers.com>"
ref_names = "tag: v3.5, master"  # incl. current branch
commit_message = """Release 3.5.
"""
